
from django.urls import path
from . import views



urlpatterns = [
    path('', views.index, name='index'),
    path('social.html', views.social, name='social'),
    path('index.html',views.index,name='homepage')
    
]

