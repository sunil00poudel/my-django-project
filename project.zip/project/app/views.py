from django.shortcuts import render
from django.http import HttpResponse

def index(request):
    return render(request, 'index.html')

def social(request):
    return render(request, 'social.html')

def index(request):
    return render(request,'index.html')
