import re

from django.http import HttpResponseForbidden
from django.template.loader import render_to_string

class MobileRestrictionMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if self.is_mobile(request):
            return HttpResponseForbidden(
                render_to_string('mobile_blocked.html')
            )
        return self.get_response(request)

    def is_mobile(self, request):
        user_agent = request.META.get('HTTP_USER_AGENT', '').lower()
        mobile_keywords = [
            'phone', 'android', 'ipad', 'tablet', 'mobile', 
            'kindle', 'windows phone', 'touch', 'blackberry',
            'opera mini', 'iemobile', 'ipod', 'webos'
        ]
        return any(re.search(rf'\b{kw}\b', user_agent) for kw in mobile_keywords)